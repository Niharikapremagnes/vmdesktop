/**
 * View Models used by Spring MVC REST controllers.
 */
package com.okta.developer.blog.web.rest.vm;
