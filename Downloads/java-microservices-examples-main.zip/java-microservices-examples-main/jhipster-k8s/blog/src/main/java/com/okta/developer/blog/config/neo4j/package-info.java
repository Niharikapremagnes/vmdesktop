/**
 * Neo4j specific configuration and required migrations.
 */
package com.okta.developer.blog.config.neo4j;
