/**
 * Service layer beans.
 */
package com.okta.developer.blog.service;
