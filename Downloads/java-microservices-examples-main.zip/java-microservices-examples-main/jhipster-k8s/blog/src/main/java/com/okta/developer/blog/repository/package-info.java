/**
 * Spring Data JPA repositories.
 */
package com.okta.developer.blog.repository;
