/**
 * Data Transfer Objects.
 */
package com.okta.developer.blog.service.dto;
