/**
 * JPA domain objects.
 */
package com.okta.developer.blog.domain;
