/**
 * JPA domain objects.
 */
package com.okta.developer.gateway.domain;
