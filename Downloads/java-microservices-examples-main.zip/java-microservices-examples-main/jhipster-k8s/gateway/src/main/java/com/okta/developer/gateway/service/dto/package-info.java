/**
 * Data Transfer Objects.
 */
package com.okta.developer.gateway.service.dto;
