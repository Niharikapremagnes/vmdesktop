/**
 * Spring Data JPA repositories.
 */
package com.okta.developer.gateway.repository;
