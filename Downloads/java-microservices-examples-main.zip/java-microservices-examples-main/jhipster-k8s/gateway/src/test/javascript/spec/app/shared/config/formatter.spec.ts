import JhiFormatter from '@/shared/config/formatter';

describe('Formatter i18n', () => {
  let formatter: JhiFormatter;

  beforeEach(() => {
    formatter = new JhiFormatter();
  });

  it('should interpolate properly given key', () => {
    const result = formatter.interpolate('{{key1}}', { key1: 'val1' });

    expect(result[0]).toBe('val1');
  });
});
