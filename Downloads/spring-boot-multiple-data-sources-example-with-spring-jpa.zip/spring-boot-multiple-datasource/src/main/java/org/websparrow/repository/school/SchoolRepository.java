package org.websparrow.repository.school;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.websparrow.entity.school.School;

@Repository
public interface SchoolRepository extends JpaRepository<School, Integer> {

}
